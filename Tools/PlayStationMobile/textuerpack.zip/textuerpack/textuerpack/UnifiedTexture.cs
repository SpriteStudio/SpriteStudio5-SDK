
using System;
using System.Collections.Generic;
using System.Xml.Linq;

namespace textuerpack
{

	public class UnifiedTextureInfo
	{
		public float tex_x;
		public float tex_y;
		public float w;
		public float h;
		public float offset_x;
		public float offset_y;
		
		public UnifiedTextureInfo(float tex_x, float tex_y, float w, float h, float offset_x, float offset_y)
		{
			this.tex_x=tex_x;
			this.tex_y=tex_y;
			this.w=w;
			this.h=h;
			this.offset_x=offset_x;
			this.offset_y=offset_y;
		}
	}
	
	public class UnifiedTexture
	{
		/// <summary>
		/// Gets the dictionary texture info.
		/// </summary>
		/// <returns>
		/// The dictionary of texture info.
		/// </returns>
		/// <param name='xmlFilename'>
		/// Xml filename.
		/// </param>
		static public Dictionary<string, UnifiedTextureInfo>　GetDictionaryTextureInfo(string xmlFilename)
		{
			Dictionary<string, UnifiedTextureInfo> dicTextureInfo = new Dictionary<string, UnifiedTextureInfo>();
			
			try
			{
				XDocument doc = XDocument.Load(xmlFilename);
				
				
				XElement root= doc.Element("root");
				
				//@e Get the size of the whole texture.
				//@j テクスチャ全体の大きさを取得する。
				var elementInfo = root.Element("info");
				float textureWidth=float.Parse(elementInfo.Attribute("w").Value);
				float textureHeight=float.Parse(elementInfo.Attribute("h").Value);
				
				Console.WriteLine(textureWidth+","+textureHeight);
				
				float x,y,w,h,offset_x,offset_y;
				
				foreach( var element in root.Descendants("texture"))
				{
					Console.WriteLine("texture "+element.Attribute("filename").Value);
					
					x=float.Parse(element.Attribute("x").Value);
					y=float.Parse(element.Attribute("y").Value);
					w=float.Parse(element.Attribute("w").Value);
					h=float.Parse(element.Attribute("h").Value);
					offset_x = float.Parse(element.Attribute("offset_x").Value);
					offset_y = float.Parse(element.Attribute("offset_y").Value);
						
					// Convert to UV.
					dicTextureInfo.Add(element.Attribute("filename").Value, 
					    new UnifiedTextureInfo(
							x,	y,
							w,	h,
						    offset_x, offset_y
						)
					 );
				}
			}
			catch (Exception e)
			{
			    Console.Error.WriteLine(e.Message);
			    Environment.Exit(1);
			}
			
			return dicTextureInfo;
		}
	}

}

