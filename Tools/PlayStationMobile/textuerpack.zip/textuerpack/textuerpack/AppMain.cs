/* PlayStation(R)Mobile SDK 2.00.00
 * Copyright (C) 2014 Sony Computer Entertainment Inc.
 * All Rights Reserved.
 */

using System;
using System.Collections.Generic;

using Sce.PlayStation.Core;
using Sce.PlayStation.Core.Graphics;
using Sce.PlayStation.Core.Imaging;
using Sce.PlayStation.Core.Environment;
using Sce.PlayStation.Core.Input;
using Sce.PlayStation.Core.Audio;
using System.Collections.Generic;


namespace textuerpack
{
	public class AppMain
	{
		public static void Main (string[] args)
		{
			Initialize ();

			while (true) {
				SystemEvents.CheckEvents ();
				Update ();
				Render ();
			}
		}

		static GamePadData gamePadData;
		public static Dictionary<string, UnifiedTextureInfo> dicTextureInfo;
		private static function func;
		private static int frame_count;
		private static bool anime_stop;
		private static bool press;
		public static void Initialize ()
		{
			func = new function();
			func.init();

			//画像読み込み
			func.Loadimage("/Application/resources/car.png", 0 );
			func.Loadimage("/Application/resources/sheet_car_car_motion_1.png", 1 );
			
			//セルシートデータの読み込み
			dicTextureInfo = UnifiedTexture.GetDictionaryTextureInfo("/Application/resources/sheet_car_car_motion_1.xml");
			
			//スプライトシートのフレーム番号
			frame_count = 0;
			anime_stop = false;
			press = false;
		}
	
		public static void Update ()
		{
			func.before_func( );	//定時処理
			
			//アニメーション更新
			if( anime_stop == false )
			{
				frame_count++;
				if ( frame_count > 60 )	//最後まで表示したら先頭に戻す
				{
					frame_count = 0;
				}
			}
			
			//キー入力でアニメーションを操作する
			gamePadData = GamePad.GetData(0);
			if((gamePadData.Buttons & GamePadButtons.Left) != 0)
	        {
				if ( press == false )
				{
					frame_count--;
					if ( frame_count < 0 )
					{
						frame_count = 60;
					}
				}
				press = true;
	        }
	        else if((gamePadData.Buttons & GamePadButtons.Right) != 0)
	        {
				if ( press == false )
				{
					frame_count++;
					if ( frame_count > 60 )
					{
						frame_count = 0;
					}
				}
				press = true;
	        }
	        else if((gamePadData.Buttons & GamePadButtons.Up) != 0)
	        {
				if ( press == false )
				{
					frame_count += 10;
					if ( frame_count > 60 )
					{
						frame_count -= 60;
					}
				}
				press = true;
	        }
	        else if((gamePadData.Buttons & GamePadButtons.Down) != 0)
	        {
				if ( press == false )
				{
					frame_count -= 10;
					if ( frame_count < 0 )
					{
						frame_count += 60;
					}
				}
				press = true;
	        }			
	        else if((gamePadData.Buttons & GamePadButtons.Circle) != 0)
	        {
				if ( press == false )
				{
					if ( anime_stop == false )
					{
						anime_stop = true;
					}
					else
					{
						anime_stop = false;
					}
					
				}
				press = true;
	        }			
			else
			{
				press = false;
			}
		}

		public static void Render ()
		{
			//ディスプレイサイズの取得
			int cx = 0;
			int cy = 0;
			func.getDisplaysize( ref cx, ref cy );
			//画面の中心座標を取得
			cx = cx / 2;
			cy = cy / 2;
			
			//描画
//			func.Blt( 0, 100, 100, 0, 0, 100, 100 );	//画像の矩形表示

			string name;
			name = string.Format("frame{0:D3}.png", frame_count);
			float ox = dicTextureInfo[name].offset_x;
			float oy = -dicTextureInfo[name].offset_y;	//SS5は上がプラスなので符号を逆にする
			float tex_x = dicTextureInfo[name].tex_x;
			float tex_y = dicTextureInfo[name].tex_y;
			float w = dicTextureInfo[name].w;
			float h = dicTextureInfo[name].h;
			func.Blt( 1, cx + (int)ox, cy + (int)oy, (int)tex_x, (int)tex_y, (int)w, (int)h );

			func.Render();
		}
	}
}
