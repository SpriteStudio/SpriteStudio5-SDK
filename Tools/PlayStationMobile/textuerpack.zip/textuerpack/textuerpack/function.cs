using System;
using Sce.PlayStation.Core;
using Sce.PlayStation.Core.Graphics;
using Sce.PlayStation.Core.Imaging;
using Sce.PlayStation.Core.Environment;
using Sce.PlayStation.Core.Input;
using Sce.PlayStation.Core.Audio;
using System.Collections.Generic;

namespace textuerpack
{
	public class function
	{
		public function ()
		{
		}
		
		public struct DRAWDATA
		{
		    public int idx;
		    public int x;
			public int y;
		    public int tex_x;
			public int tex_y;
		    public int w;
			public int h;
		
		    public void Clear( )
		    {
				idx = 0;
		        x = 0;
		        y = 0;
				tex_x = 0;
				tex_y = 0;
				w = 0;
				h = 0;
		    }
		}				
		
		private GraphicsContext graphics;		
		private VertexBuffer vertexBuffer;
		private Matrix4 screenMatrix;
		private int indexSize = 4;
		private ushort[] indices;	
		private ShaderProgram shaderProgram;
		private int sprit_count;
		private const int SPRITE_MAX = 1024;
		private DRAWDATA[] drawdata = new DRAWDATA[1024];
		private Texture2D[] tex = new Texture2D[32];
		
		//初期化
		public void init( )
		{
			int i;
			for( i = 0; i < 32; i++ )
			{
				tex[i] = null;
			}
			graphics = new GraphicsContext( 960, 544, PixelFormat.Rgba, PixelFormat.Depth16, MultiSampleMode.None );		
			
			shaderProgram = new ShaderProgram("/Application/shaders/Sprite.cgx");
		    shaderProgram.SetUniformBinding(0, "u_ScreenMatrix");

			indices = new ushort[indexSize];
			indices[0] = 0;
			indices[1] = 1;
			indices[2] = 2;
			indices[3] = 3;
			
			ImageRect rectScreen = graphics.Screen.Rectangle;
			screenMatrix = new Matrix4(
				 2.0f/rectScreen.Width,	0.0f,	    0.0f, 0.0f,
				 0.0f,   -2.0f/rectScreen.Height,	0.0f, 0.0f,
				 0.0f,   0.0f, 1.0f, 0.0f,
				 -1.0f,  1.0f, 0.0f, 1.0f
			);
			//												vertex pos,               texture,       color
			vertexBuffer = new VertexBuffer(4, indexSize, VertexFormat.Float3, VertexFormat.Float2, VertexFormat.Float4);
			
		}
		//テクスチャの読み込み
		public void Loadimage( string name, int idx )
		{
			if ( tex[idx] == null )
			{
				Releseimage( idx );
				tex[idx] = new Texture2D(name, false, PixelFormat.Rgba);
			}
		}
		public void Releseimage( int idx )
		{
			if ( tex[idx] != null )
			{
				tex[idx].Dispose();
				tex[idx] = null;
			}
		}
		//ディスプレイサイズの取得
		public void getDisplaysize( ref int w, ref int h )
		{
			ImageRect rectScreen = graphics.Screen.Rectangle;
			w = rectScreen.Width;			
			h = rectScreen.Height;			
		}
		
		//フレーム開始時の処理
		public void before_func( )
		{
			sprit_count = 0;
		}
		
		//画像表示
		public void Blt( int idx, int x, int y, int tex_x, int tex_y, int w, int h )
		{
//			drawdata[sprit_count].Clear();
			drawdata[sprit_count].idx = idx;
			drawdata[sprit_count].x = x;
			drawdata[sprit_count].y = y;
			drawdata[sprit_count].tex_x = tex_x;
			drawdata[sprit_count].tex_y = tex_y;
			drawdata[sprit_count].w = w;
			drawdata[sprit_count].h = h;
			
			sprit_count++;
		}
		
		//レンダリング
		public void Render ()
		{
			graphics.Clear();
			
			int i;
			for ( i = 0; i < sprit_count; i++ )
			{
				float[] vertices=new float[12];
				
				float tex_w = tex[drawdata[i].idx].Width;
				float tex_h = tex[drawdata[i].idx].Height;
				float u1 = (float)drawdata[i].tex_x / tex_w;
				float v1 = (float)drawdata[i].tex_y / tex_h;
				float u2 = (float)( drawdata[i].tex_x + drawdata[i].w ) / tex_w;
				float v2 = (float)( drawdata[i].tex_y + drawdata[i].h ) / tex_h;
				
				float[] texcoords = {
				    u1, v1, // 0 top left.
				    u1, v2, // 1 bottom left.
				    u2, v1, // 2 top right.
				    u2, v2, // 3 bottom right.
				};
				
				float[] colors = {
				    1.0f,   1.0f,   1.0f,   1.0f,   // 0 top left.
				    1.0f,   1.0f,   1.0f,   1.0f,   // 1 bottom left.
				    1.0f,   1.0f,   1.0f,   1.0f,   // 2 top right.
				    1.0f,   1.0f,   1.0f,   1.0f,   // 3 bottom right.
				};

				float x = (float)drawdata[i].x - ( drawdata[i].w / 2.0f );
				float y = (float)drawdata[i].y - ( drawdata[i].h / 2.0f );
				
				vertices[0]= x;   // x0
				vertices[1]= y;   // y0
				vertices[2]= 0.0f;   // z0
				
				vertices[3]= x;   // x1
				vertices[4]= y + (float)drawdata[i].h; // y1
				vertices[5]= 0.0f;   // z1
				
				vertices[6]= x + (float)drawdata[i].w;  // x2
				vertices[7]= y;   // y2
				vertices[8]= 0.0f;   // z2
				
				vertices[9]= x + (float)drawdata[i].w;  // x3
				vertices[10]= y + (float)drawdata[i].h;    // y3
				vertices[11]= 0.0f;  // z3	
				
				
				vertexBuffer.SetVertices(0, vertices);
				vertexBuffer.SetVertices(1, texcoords);
				vertexBuffer.SetVertices(2, colors);
				
				vertexBuffer.SetIndices(indices);
				graphics.SetVertexBuffer(0, vertexBuffer);
				
				graphics.SetShaderProgram(shaderProgram);
				graphics.SetTexture(0, tex[drawdata[i].idx]);
				shaderProgram.SetUniformValue(0, ref screenMatrix);
				
				graphics.DrawArrays(DrawMode.TriangleStrip, 0, indexSize);
				
			}
			
			graphics.SwapBuffers();	
		}
		
	}
}

