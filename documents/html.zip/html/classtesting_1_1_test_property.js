var classtesting_1_1_test_property =
[
    [ "TestProperty", "classtesting_1_1_test_property.html#a2ebe8f9312fe2aa2e438f7d061d0be61", null ],
    [ "key", "classtesting_1_1_test_property.html#a2c569d47685b89aa64e737fb11df3aba", null ],
    [ "SetValue", "classtesting_1_1_test_property.html#acda79bfc4f3b3acc833d35b03eac10ba", null ],
    [ "value", "classtesting_1_1_test_property.html#ad46323c18491f365d72d8a4288f54bd6", null ]
];