var classtesting_1_1internal_1_1_test_case_name_is =
[
    [ "TestCaseNameIs", "classtesting_1_1internal_1_1_test_case_name_is.html#aba668706e1635e699c5ac1ccaa2994ea", null ],
    [ "operator()", "classtesting_1_1internal_1_1_test_case_name_is.html#a6d6b1bf43aa7105aee9ef44edbc6d2e8", null ]
];