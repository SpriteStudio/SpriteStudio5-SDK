var classtesting_1_1internal_1_1_captured_stream =
[
    [ "CapturedStream", "classtesting_1_1internal_1_1_captured_stream.html#a4b05e68491831448c5c575a25146e53d", null ],
    [ "~CapturedStream", "classtesting_1_1internal_1_1_captured_stream.html#af215c7a9326cb5ca61e6b7ca8231dcf1", null ],
    [ "GetCapturedString", "classtesting_1_1internal_1_1_captured_stream.html#a5a5e656cc0657d8ae56a1911168f6bb5", null ]
];