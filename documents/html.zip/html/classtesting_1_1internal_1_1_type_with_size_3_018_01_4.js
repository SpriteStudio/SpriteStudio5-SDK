var classtesting_1_1internal_1_1_type_with_size_3_018_01_4 =
[
    [ "Int", "classtesting_1_1internal_1_1_type_with_size_3_018_01_4.html#a36d5697e5f5254b0495f13c97d747e36", null ],
    [ "UInt", "classtesting_1_1internal_1_1_type_with_size_3_018_01_4.html#a747e21c5aee8faf07ec65cd4c3d1ca62", null ]
];