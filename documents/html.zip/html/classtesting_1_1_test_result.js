var classtesting_1_1_test_result =
[
    [ "TestResult", "classtesting_1_1_test_result.html#a5cf5dd6f416b7334ea601aab21a2fda5", null ],
    [ "~TestResult", "classtesting_1_1_test_result.html#a41f407680b725b75d7eadc3230bc3315", null ],
    [ "elapsed_time", "classtesting_1_1_test_result.html#a582f6383265d0619df812b75499d0616", null ],
    [ "Failed", "classtesting_1_1_test_result.html#abb5d051bf958071c14020132a4d6cc07", null ],
    [ "GetTestPartResult", "classtesting_1_1_test_result.html#a08b680f63d91391db4161f909da2bbcc", null ],
    [ "GetTestProperty", "classtesting_1_1_test_result.html#a2cb23a457a444ba85684dd655895f08e", null ],
    [ "HasFatalFailure", "classtesting_1_1_test_result.html#ace61ce992083a9124f9ff0e99a2041cc", null ],
    [ "HasNonfatalFailure", "classtesting_1_1_test_result.html#a34e6901b9772f51ce4f17a5517c26607", null ],
    [ "Passed", "classtesting_1_1_test_result.html#aa46a04342f02ec297357f47288da3ef3", null ],
    [ "test_property_count", "classtesting_1_1_test_result.html#a5075f9d595d51c7cc2f5c0921e622831", null ],
    [ "total_part_count", "classtesting_1_1_test_result.html#ae6a378ec743edfbed55890c955d0adc8", null ],
    [ "internal::DefaultGlobalTestPartResultReporter", "classtesting_1_1_test_result.html#abae39633da9932847b41cb80efd62115", null ],
    [ "internal::ExecDeathTest", "classtesting_1_1_test_result.html#adf5553cae6aea6f8648d47e299237e34", null ],
    [ "internal::TestResultAccessor", "classtesting_1_1_test_result.html#ae762da04e74a0d3b0daded3c5bd4a8e8", null ],
    [ "internal::UnitTestImpl", "classtesting_1_1_test_result.html#acc0a5e7573fd6ae7ad1878613bb86853", null ],
    [ "internal::WindowsDeathTest", "classtesting_1_1_test_result.html#a6aeedc04a0590fcc1b3c5f687dbb0f9f", null ],
    [ "TestInfo", "classtesting_1_1_test_result.html#a4c49c2cdb6c328e6b709b4542f23de3c", null ],
    [ "UnitTest", "classtesting_1_1_test_result.html#a832b4d233efee1a32feb0f4190b30d39", null ]
];