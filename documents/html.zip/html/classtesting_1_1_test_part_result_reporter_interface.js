var classtesting_1_1_test_part_result_reporter_interface =
[
    [ "~TestPartResultReporterInterface", "classtesting_1_1_test_part_result_reporter_interface.html#a338b51591ed654f84dc0feaaf2b66917", null ],
    [ "ReportTestPartResult", "classtesting_1_1_test_part_result_reporter_interface.html#aa2f920e7a5a0a6d0faf19e3727928c22", null ]
];