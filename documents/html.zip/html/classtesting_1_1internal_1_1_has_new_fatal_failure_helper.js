var classtesting_1_1internal_1_1_has_new_fatal_failure_helper =
[
    [ "HasNewFatalFailureHelper", "classtesting_1_1internal_1_1_has_new_fatal_failure_helper.html#a59190a7188db558c00b4c6bf9251859a", null ],
    [ "~HasNewFatalFailureHelper", "classtesting_1_1internal_1_1_has_new_fatal_failure_helper.html#a913b1bc7c372868c9b2dbb009044ee97", null ],
    [ "has_new_fatal_failure", "classtesting_1_1internal_1_1_has_new_fatal_failure_helper.html#ae137e639098071f11f531bbd72dde1c7", null ],
    [ "ReportTestPartResult", "classtesting_1_1internal_1_1_has_new_fatal_failure_helper.html#a2d2e1faa1f3669b82810df97ac678a27", null ]
];