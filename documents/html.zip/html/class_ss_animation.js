var class_ss_animation =
[
    [ "SsAnimation", "class_ss_animation.html#a718881e2d893c2ab1c0c2cba3636b3c6", null ],
    [ "~SsAnimation", "class_ss_animation.html#a35a2968466094f740a61a592291bb706", null ],
    [ "SSAR_DECLARE_LISTEX", "class_ss_animation.html#a4dcc2fee3d0abec933e0d5a68c8697bf", null ],
    [ "SSAR_STRUCT_DECLARE", "class_ss_animation.html#ab50797e353d396c42447344330ab73ea", null ],
    [ "name", "class_ss_animation.html#ad43ce472688821793af411096acc9055", null ],
    [ "overrideSettings", "class_ss_animation.html#a03e362dd02cf292d37b0d0c39c6352e2", null ],
    [ "partAnimes", "class_ss_animation.html#ac45fc3f8016105f56ab5e41364f5d280", null ],
    [ "settings", "class_ss_animation.html#a322ff1260171708ddf502e5a05da57e5", null ],
    [ "SSSERIALIZE_BLOCK", "class_ss_animation.html#a149b229677d4db5bfa796d6e1ad2737b", null ]
];