var classtesting_1_1internal_1_1_xml_unit_test_result_printer =
[
    [ "XmlUnitTestResultPrinter", "classtesting_1_1internal_1_1_xml_unit_test_result_printer.html#afdaf88e6764c18ce0dcc3733d7a06e31", null ],
    [ "OnTestIterationEnd", "classtesting_1_1internal_1_1_xml_unit_test_result_printer.html#a2ae986dd2f4f2aed31cc6f3bc8c56898", null ]
];