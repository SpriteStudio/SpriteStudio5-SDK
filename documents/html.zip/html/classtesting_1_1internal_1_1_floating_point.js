var classtesting_1_1internal_1_1_floating_point =
[
    [ "Bits", "classtesting_1_1internal_1_1_floating_point.html#abf228bf6cd48f12c8b44c85b4971a731", null ],
    [ "FloatingPoint", "classtesting_1_1internal_1_1_floating_point.html#a0dabf840863e0df84046f171c891fe71", null ],
    [ "AlmostEquals", "classtesting_1_1internal_1_1_floating_point.html#adb0fe9ab1d9e5288f8e5550234211166", null ],
    [ "bits", "classtesting_1_1internal_1_1_floating_point.html#abead51f16ec6ea84360a976da1cd1387", null ],
    [ "exponent_bits", "classtesting_1_1internal_1_1_floating_point.html#af53c50b85408c582540d6244c026ce2b", null ],
    [ "fraction_bits", "classtesting_1_1internal_1_1_floating_point.html#aa0167b7b10a934b743ba3c1f47421e63", null ],
    [ "is_nan", "classtesting_1_1internal_1_1_floating_point.html#aaef2fd2cd8cdf791206a5e9fed8ef90d", null ],
    [ "sign_bit", "classtesting_1_1internal_1_1_floating_point.html#a6176cc4d443724477f2799bcbd9f020a", null ]
];