var class_ss_model =
[
    [ "SsModel", "class_ss_model.html#a8d3a0b6b99e81c2bb4307809df5a291e", null ],
    [ "~SsModel", "class_ss_model.html#a2783f9709b85e9b1a425549569bdf03e", null ],
    [ "partList", "class_ss_model.html#a9629778dae8c80aaf608a3f5be101aed", null ],
    [ "SSSERIALIZE_BLOCK", "class_ss_model.html#ad25b790068bfedbc9e1c1e3f667bd9cd", null ]
];