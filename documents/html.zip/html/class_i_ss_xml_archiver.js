var class_i_ss_xml_archiver =
[
    [ "ISsXmlArchiver", "class_i_ss_xml_archiver.html#a13d865187e14252bc835663b508bdec5", null ],
    [ "~ISsXmlArchiver", "class_i_ss_xml_archiver.html#aa3abb6e4464b320e423d13065b9675ca", null ],
    [ "dc", "class_i_ss_xml_archiver.html#ad41476ac8416fae207fcad403cdbfe8c", null ],
    [ "dc", "class_i_ss_xml_archiver.html#a1b5f25ccb8382dc4a472b9b49aef6b41", null ],
    [ "dc", "class_i_ss_xml_archiver.html#a421c583e948db64134b47967b0f440ea", null ],
    [ "dc", "class_i_ss_xml_archiver.html#a3215936f783c2ef58190d5f9bc992153", null ],
    [ "dc", "class_i_ss_xml_archiver.html#a3415b17da09bca9a6d8f1620f94fda5e", null ],
    [ "dc", "class_i_ss_xml_archiver.html#a2304c664e4001ff941e63d8c8497528d", null ],
    [ "dc", "class_i_ss_xml_archiver.html#a8366decc352559debbbd3f9ec946d0a6", null ],
    [ "dc_attr", "class_i_ss_xml_archiver.html#ab696b580a68b1b55ea117597f508e7cd", null ],
    [ "dc_attr", "class_i_ss_xml_archiver.html#a2e20261de50e91dcd01d04c529ccdb6d", null ],
    [ "firstChild", "class_i_ss_xml_archiver.html#a86d24dcc1b505da69a15b6f532b35a46", null ],
    [ "getType", "class_i_ss_xml_archiver.html#a1d7fe7b298bfc0bfd5510200ccd09d45", null ],
    [ "getxml", "class_i_ss_xml_archiver.html#ae6c3a593b8e188fac68ebe2c3e221e52", null ],
    [ "setDocumet", "class_i_ss_xml_archiver.html#a7351d64ce13bc1d7516833c42ed8b241", null ],
    [ "setElement", "class_i_ss_xml_archiver.html#ad91fc0e143139c685b6ac012f6f7306b", null ]
];