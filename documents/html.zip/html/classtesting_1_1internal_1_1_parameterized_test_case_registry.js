var classtesting_1_1internal_1_1_parameterized_test_case_registry =
[
    [ "ParameterizedTestCaseRegistry", "classtesting_1_1internal_1_1_parameterized_test_case_registry.html#aacafaaf78ca09bbd9f5eed93ae2b6225", null ],
    [ "~ParameterizedTestCaseRegistry", "classtesting_1_1internal_1_1_parameterized_test_case_registry.html#a695c86db8545a3745873190b91a13c9f", null ],
    [ "GetTestCasePatternHolder", "classtesting_1_1internal_1_1_parameterized_test_case_registry.html#af81b3fffa8c9a26256417b85aceb9e80", null ],
    [ "RegisterTests", "classtesting_1_1internal_1_1_parameterized_test_case_registry.html#ad5b63c8fe94f3d51d039a76c001c9223", null ]
];