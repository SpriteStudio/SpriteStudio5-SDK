var class_ss_animation_settings =
[
    [ "SsAnimationSettings", "class_ss_animation_settings.html#a8a27969c461abbf7e237fe90bb3d7ea3", null ],
    [ "~SsAnimationSettings", "class_ss_animation_settings.html#a84d8a8496ae8bdc892e1bdc30203547f", null ],
    [ "SSAR_DECLARE", "class_ss_animation_settings.html#ad6c4bbba607826baaebebf1c2edd0b24", null ],
    [ "SSAR_DECLARE", "class_ss_animation_settings.html#abd96b4c89fdf9a6e0b0b871313295302", null ],
    [ "SSAR_DECLARE", "class_ss_animation_settings.html#a65aa7866c72aedbd9c97f17c31b7aaca", null ],
    [ "canvasSize", "class_ss_animation_settings.html#ada75be3c966a6804cd04c78c07dafb21", null ],
    [ "fps", "class_ss_animation_settings.html#a759fc9dafee6052230730ad01445775d", null ],
    [ "frameCount", "class_ss_animation_settings.html#ad3fc575e84cbc793afc6f1f2edbaf363", null ],
    [ "pivot", "class_ss_animation_settings.html#aaf43b5e1cd0b908dcad45c561f11c562", null ],
    [ "sortMode", "class_ss_animation_settings.html#a90aea52a1848ad9ce7653acd281e6728", null ],
    [ "SSSERIALIZE_BLOCK", "class_ss_animation_settings.html#adfdf2668794abbf3729e476e0de52a4d", null ]
];