var classtesting_1_1internal_1_1linked__ptr__internal =
[
    [ "depart", "classtesting_1_1internal_1_1linked__ptr__internal.html#ab916efbc0c2776dacaa06222ea2e11e5", null ],
    [ "join", "classtesting_1_1internal_1_1linked__ptr__internal.html#a41918df82256ae6ab7a6888ed628dd0a", null ],
    [ "join_new", "classtesting_1_1internal_1_1linked__ptr__internal.html#a742af1f65df2d5e2b7198a1b74264a83", null ]
];