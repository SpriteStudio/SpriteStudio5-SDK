var classtesting_1_1internal_1_1_os_stack_trace_getter_interface =
[
    [ "OsStackTraceGetterInterface", "classtesting_1_1internal_1_1_os_stack_trace_getter_interface.html#afbe9eb0ca8775fbb98ff0720011b6708", null ],
    [ "~OsStackTraceGetterInterface", "classtesting_1_1internal_1_1_os_stack_trace_getter_interface.html#a193f4a1de4af9b78010c659912df5a15", null ],
    [ "CurrentStackTrace", "classtesting_1_1internal_1_1_os_stack_trace_getter_interface.html#ac8cb5eb539c3da9d236213d495057735", null ],
    [ "UponLeavingGTest", "classtesting_1_1internal_1_1_os_stack_trace_getter_interface.html#a791bd120428b5a53d5eeba1b27296a39", null ]
];