var classtesting_1_1internal_1_1_scoped_trace =
[
    [ "ScopedTrace", "classtesting_1_1internal_1_1_scoped_trace.html#ab965d7010bbbc82c1bef6ebf8748bede", null ],
    [ "~ScopedTrace", "classtesting_1_1internal_1_1_scoped_trace.html#a658c7c098ff48337058bfa2ccab65881", null ]
];